import java.io.*; // used for input and output operations
import java.net.*;// used for network communication such as Socket and ServerSocket

public class gameDaemon {
    public static void main(String[] args) {
        try {
            // create out server socket
            ServerSocket serverSocket = new ServerSocket(42456);
            // print message showing that our server is running
            System.out.println("Your server is running... yay!");

            // accept our client connection indefinitely
            while (true) {
                // accepts client connection
                Socket socket = serverSocket.accept();
                // starts a new game thread for each client/time
                gameThread thread = new gameThread(socket);
                thread.start();
            }
        } catch (IOException e) {
            e.printStackTrace(); // was used for error handling
        }
    }
}

/*
Sample Execution 1:
Secret Code: RYGG

Welcome to Mastermind. You will try to guess a 4 color code using
only the letters ( R, Y, G, B, W, O). You will lose the game if you
are unable to guess the code correctly in 20 guesses. Good Luck!

Please enter your guess for the secret code or “QUIT” :
YRGW
Please enter your guess for the secret code or “QUIT” :
YRGW CCP
YRWW
Please enter your guess for the secret code or “QUIT” :
YRWW CC
GGRY
Please enter your guess for the secret code or “QUIT” :
GGRY CCCC
YRGG
Please enter your guess for the secret code or “QUIT” :
YRGG CCPP
RYGG
Please enter your guess for the secret code or “QUIT” :
RYGG PPPP
Congratulations!!! You guessed the code correctly in 5 moves.

Process finished with exit code 0


Sample Execution 2:
Secret Code: BBBW

Welcome to Mastermind. You will try to guess a 4 color code using
only the letters ( R, Y, G, B, W, O). You will lose the game if you
are unable to guess the code correctly in 20 guesses. Good Luck!

Please enter your guess for the secret code or “QUIT” :
WBOB
Please enter your guess for the secret code or “QUIT” :
WBOB CCP
OBWO
Please enter your guess for the secret code or “QUIT” :
OBWO CP
WOOB
Please enter your guess for the secret code or “QUIT” :
WOOB CC
QUIT
Goodbye but please play again!

Process finished with exit code 0
 */
