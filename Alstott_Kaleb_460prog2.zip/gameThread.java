import java.io.*; // used for input and output operations
import java.net.*; // used for network communication such as Socket and ServerSocket
import java.util.*; // used for random so we can random generate our secret code

public class gameThread extends Thread {
    private Socket socket;

    // constructor to initialize the socket
    public gameThread(Socket socket) {
        this.socket = socket;
    }

    // method to run the game logic
    public void run() {
        try {
            //  buffered reader to read input from client
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            //  print writer to send output to client
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);

            // array of colors to generate the secret code
            String[] colors = {"R", "Y", "G", "B", "W", "O"};
            // generates the secret code
            String secretCode = generateSecretCode(colors);

            // sends signal to the client to start the game
            output.println("GO");

            // outputs the secret code to the client so we can see the secret code
            System.out.println("Secret Code: " + secretCode);

            // counter to track number of guesses
            int counter = 0;

            // game loop
            while (counter < 20) {
                // receives guess from the client
                String guess = input.readLine();

                if (guess.equals("QUIT")) {
                    // ends the game if the client wants to ever quit
                    break;
                }

                // processes the guess and generates the response
                String result = processGuess(guess, secretCode);

                // sends the response to the client
                output.println(result);

                if (result.equals("PPPP")) {
                    // ends the game if the client guesses the code correctly
                    break;
                }

                counter++; // increment the count of the game from the guesses
            }

            // close open socket
            socket.close();
        } catch (IOException e) {
            // used for error handling
            e.printStackTrace();
        }
    }

    // generates a random secret code
    private String generateSecretCode(String[] colors) {
        // create a new Random object to generate random numbers
        Random random = new Random();
        // create a StringBuilder to construct the secret code
        StringBuilder code = new StringBuilder();
        // iterate four times to generate four characters for the secret code
        for (int i = 0; i < 4; i++) {
            // generate a random index to select a color from the array of colors
            int index = random.nextInt(colors.length);
            // append the randomly selected color to the secret code
            code.append(colors[index]);
        }
        // convert our StringBuilder to a String and return the secret code to be used
        return code.toString();
    }


    private String processGuess(String guess, String secretCode) {
        StringBuilder result = new StringBuilder();

        // boolean arrays to keep track of matched positions and characters
        boolean[] matchingPositions = new boolean[4];
        boolean[] matchingCharacters = new boolean[4];

        // check for correct characters in wrong positions our C's
        for (int i = 0; i < guess.length(); i++) {
            if (guess.charAt(i) != secretCode.charAt(i)) { // if the character is not in the correct position
                for (int j = 0; j < secretCode.length(); j++) {
                    // find a character in the secret code that has not been matched yet and matches the character in the guess
                    if (!matchingCharacters[j] && guess.charAt(i) == secretCode.charAt(j)) {
                        result.append("C"); // add a C to the result string
                        matchingCharacters[j] = true; // mark the character in the secret code as matched
                        break;
                    }
                }
            }
        }

        // check for correct characters in correct positions, our P's
        for (int i = 0; i < guess.length(); i++) {
            if (guess.charAt(i) == secretCode.charAt(i)) { // if the character is in the correct position
                result.append("P"); // add a P to the result string
                matchingPositions[i] = true; // mark the position as matched
                matchingCharacters[i] = true; // mark the character as matched
            }
        }

        // fill remaining positions with blanks
        while (result.length() < 4) {
            result.append(" ");
        }

        return result.toString(); // return the result string
    }
}
