import java.io.*; // input and output operations
import java.net.*; // used for network communication such as Socket and ServerSocket

public class mastermind {
    public static void main(String args[]) {
        try {
            // establish a connection with the server
            Socket socket = new Socket("localhost", 42456);
            //  buffered reader to read input from server
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            //  print writer to send output to server
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);

            // counter to track number of guesses from user
            int counter = 0;
            //  user guess
            String guessString = "";

            // welcome message and game instructions
            System.out.println("Welcome to Mastermind. You will try to guess a 4 color code using\n" +
                    "only the letters ( R, Y, G, B, W, O). You will lose the game if you\n" +
                    "are unable to guess the code correctly in 20 guesses. Good Luck!\n");

            // game loop
            while (counter < 20) {
                // prompts the user to enter their guess
                System.out.println("Please enter your guess for the secret code or “QUIT” :");

                // reads our response from the server
                String response = input.readLine();

                if (response.equals("GO")) {
                    // server indicates that user should enter a guess and that the game is starting
                    //  our prompt will still be displayed here by the client loop
                } else if (response.equals("PPPP")) {
                    // if the response from the server is "PPPP"  then the user has guessed the code correctly which will then
                    // display the final guess and congratulatory message
                    System.out.println(guessString + " PPPP");
                    System.out.println("Congratulations!!! You guessed the code correctly in " + counter + " moves.");
                    return;
                } else {
                    // displays the guess and response from  server
                    System.out.println(guessString + " " + response);
                }

                // reads user guess from standard input and is stored
                BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
                guessString = userInput.readLine();

                // checks if the user wants to quit the game
                if (guessString.equals("QUIT")) {
                    output.println("QUIT");
                    System.out.println("Goodbye but please play again!");
                    return;
                }

                // verifies if the user guess is valid
                while (!verifyInput(guessString)) {
                    System.out.println("Invalid input. Please enter a valid guess:");
                    guessString = userInput.readLine(); // allows the user to reenter their guess after wrong guess
                    if (guessString.equals("QUIT")) { // checks if user wants to quit after they have entered the invalid guess
                        output.println("QUIT");
                        System.out.println("Goodbye but please play again!");
                        return;
                    }
                }

                // sends user guess to the server as well as increase count of game
                output.println(guessString);
                counter++;
            }

            //  if the user has guessed the 20 guesses let them know they are done
            System.out.println("Sorry, that was your 20th guess. You have LOST the game. Please try again!");
            socket.close(); // close open socket
        } catch (IOException e) { // used for error handling
            e.printStackTrace();
        }
    }

    // verifies if the user guess is valid
    static boolean verifyInput(String gs) {
        return gs.length() == 4 && gs.matches("[RYGBWO]*|QUIT"); // verifies that there are 4 characters and correct input
    }
}
