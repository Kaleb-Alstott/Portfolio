// class a and b extends Thread
class Aclass extends Thread {
    // Private long store time_to_sleep and private progState count
    private long time_to_sleep;
    private progState count;

    // constructor for Aclass taking progState and time_to_sleep arguments taking in two arguments
    public Aclass(progState count, long time_to_sleep) {
        this.count = count;  // Store the progState object
        this.time_to_sleep = time_to_sleep;  // Store the time to sleep time
    }

    // Run method for threaded classes
    public void run() {
        // Synchronize access to the progState object to avoid any race conditions
        synchronized (count) {
            // Increment count of class A objects and print message about it
            count.incA();
            System.out.println("Class A " + getName() + " is INCrementing");
        }

        try {
            // Print a message letting user know preparing to sleep for x time
            System.out.println("Class A " + getName() + " Preparing to sleep for " + time_to_sleep + " milliseconds");
            // Sleep for the time specified
            sleep(time_to_sleep);
            // Print message indicating being Awake
            System.out.println("Class A " + getName() + " is now AWAKE");
        } catch (InterruptedException e) {
            e.printStackTrace();  // Handle interrupted exception if sleep is interrupted
        }

        // Synchronize access to the progState object again
        synchronized (count) {
            // Decrement count of class A objects and print message about it
            count.decA();
            System.out.println("Class A " + getName() + " is DECrementing");
            // Print a message indicating exit of the class object thread
            System.out.println("Class A " + getName() + " EXITING!!!");
        }
    }
}
