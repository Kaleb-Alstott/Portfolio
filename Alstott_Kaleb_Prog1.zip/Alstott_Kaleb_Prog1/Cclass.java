// Cclass implements Runnable instead of extending Thread, we use Thread.currentThread().getName()
// to get the name of the current thread at the very bottom of the class.
// both classes C and D implemnt runnable instead of extends Thread
class Cclass implements Runnable {
    // Private data type to store time_to_sleep and progState count
    private long time_to_sleep;
    private progState count;

    // Constructor for Cclass taking progState and time_to_sleep arguments
    public Cclass(progState count, long time_to_sleep) {
        this.count = count;  // Store the progState object
        this.time_to_sleep = time_to_sleep;  // Store the sleep time
    }

    // Run method for all threaded classes
    public void run() {
        // Synchronize access to the progState object to avoid any race conditions
        synchronized (count) {
            // Increment the count of class C objects and print message about it
            count.incC(); //inc count of class C
            System.out.println("Class C " + Thread.currentThread().getName() + " is INCrementing"); //print out class c call to thre thread name followed by is incrementing
        }

        try {
            // a message indicating preparation to sleep for x amount of time
            System.out.println("Class C " + Thread.currentThread().getName() + " Preparing to sleep for " + time_to_sleep + " milliseconds");
            // Sleep for the specified amount
            Thread.sleep(time_to_sleep);
            // Print a message indicating the thread is now Awake
            System.out.println("Class C " + Thread.currentThread().getName() + " is now AWAKE");
        } catch (InterruptedException e) {
            e.printStackTrace();  // Handle interrupted exception if sleep is interrupted
        }

        // Synchronize access to the progState object again
        synchronized (count) {
            // Decrement the count of class C objects and print a message about it
            count.decC();
            System.out.println("Class C " + Thread.currentThread().getName() + " is DECrementing");
            // Print a message indicating exit of the object thread
            System.out.println("Class C " + Thread.currentThread().getName() + " EXITING!!!");
        }
    }
}