class Dclass implements Runnable {
    // Private data types to store time_to_sleep and progState count
    private long time_to_sleep;
    private progState count;

    // Constructor for Dclass taking progState and time_to_sleep arguments
    public Dclass(progState count, long time_to_sleep) {
        this.count = count;  // Store the progState object
        this.time_to_sleep = time_to_sleep;  // Store the sleep time
    }

    // Run method for all threaded classes
    public void run() {
        // Synchronize access to the progState object to avoid any race conditions
        synchronized (count) {
            // Increment the count of class D objects and print message about incrementing
            count.incD();
            System.out.println("Class D " + Thread.currentThread().getName() + " is INCrementing");
        }

        try {
            // Print a message indicating preparation to sleep for x amount of time
            System.out.println("Class D " + Thread.currentThread().getName() + " Preparing to sleep for " + time_to_sleep + " milliseconds");
            // Sleep for the specified amount of time
            Thread.sleep(time_to_sleep);
            // Print a message indicating the thread being Awake
            System.out.println("Class D " + Thread.currentThread().getName() + " is now AWAKE");
        } catch (InterruptedException e) {
            e.printStackTrace();  // Handle interrupted exception if sleep is interrupted
        }

        // Synchronize access to the progState object again
        synchronized (count) {
            // Decrement the count of class D objects and print message indicating decrementing
            count.decD();
            System.out.println("Class D " + Thread.currentThread().getName() + " is DECrementing");
            // Print a message indicating thread has exited
            System.out.println("Class D " + Thread.currentThread().getName() + " EXITING!!!");
        }
    }
}
