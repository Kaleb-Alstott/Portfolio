public class myCounter {
    protected int total; // Total counter value

    // Constructor to initialize the total value
    public myCounter(int total) {
        this.total = total;
    }

    // Getter method to retrieve the total value
    public int getTotal() {
        return total;
    }

    // Setter method to set the total value
    public void setTotal(int val) {
        this.total = val;
    }
}
