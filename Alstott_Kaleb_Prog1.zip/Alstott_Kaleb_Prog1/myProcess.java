import java.util.Random;
import java.util.concurrent.Semaphore;

public class myProcess extends Thread {
    private long time_to_sleep; // Time to sleep before execution variable
    private static Semaphore mutex = new Semaphore(1); // Semaphore for mutual exclusion
    private myCounter counter; // Counter object

    // Constructor to initialize myCounter and time_to_sleep with correct arguments
    public myProcess(myCounter counter, long time_to_sleep) {
        this.counter = counter;
        this.time_to_sleep = time_to_sleep;
    }

    // Run method of the thread
    public void run() {
        //start of the threads
        System.out.println("Process " + Thread.currentThread().getName() + " is starting.");
        try {
            // Sleep for specified time
            Thread.sleep(time_to_sleep);

            // Generate random number between -200 and +200
            Random rand = new Random();
            int randomNum = rand.nextInt(401) - 200;
            //print the thread that has the value of the randomized int
            System.out.println("Process " + Thread.currentThread().getName() + " has value of " + randomNum);

            // Obtain mutual exclusion
            System.out.println("Process " + Thread.currentThread().getName() + " is obtaining Mutual Exclusion");
            mutex.acquire();

            // Update counter with random number
            counter.setTotal(counter.getTotal() + randomNum);

            // Release mutual exclusion
            System.out.println("Process " + Thread.currentThread().getName() + " is releasing Mutual Exclusion");
            mutex.release();

            // Complete execution of the thread
            System.out.println("Process " + Thread.currentThread().getName() + " COMPLETE");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
