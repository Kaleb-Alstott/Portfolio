// Class noSynch is a threaded class used to access and alter the value of a shared static integer.
public class noSynch extends Thread {
    // Declare a protected static int named total initialized to 0.
    protected static int total = 0;

    // Declare a private int named value to hold the value to be added or subtracted.
    private int value;

    // Constructor-Takes a single integer argument and assigns it to the value variable.
    public noSynch(int value) {
        this.value = value;
    }

    // Run method for the thread.
    public void run() {
        // Declare a local variable to simulate standard increment.
        int local;

        // Get the current value of the shared total variable.
        local = total;

        // Add the value to the local variable.
        local += value;

        // Update the shared total variable with the new value.
        total = local;
    }

    // Static method to get the total value.
    public static int getTotal() {
        return total; // total value
    }
}
