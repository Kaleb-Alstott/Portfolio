import java.util.Random; // Importing the Random class to generate random numbers.
import java.util.Vector; // Importing the Vector class to use dynamic arrays.
import java.util.Iterator; // Importing the Iterator interface to iterate over
import java.io.BufferedReader; // Importing the BufferedReader class to read text from an input stream.
import java.io.FileReader; // Importing the FileReader class to read files.
import java.io.IOException; // Importing the IOException class to handle input/output errors.
import java.util.Scanner; // Importing the Scanner class to read user input.

public class prog1 {
    public static void main(String[] args) {
        // Start of Part One

        // statment letting user know start of Part 1
        System.out.println("PART 1 \n");

        // Create a Random object to generate random numbers
        Random random = new Random();

        // Initialize our int of trueCount to 0
        int trueCount = 0;

        // declare a construct, create a Vector to store instances of the noSynch objects created
        Vector<noSynch> vector = new Vector<>();

        // Create and start 100 noSynch threads
        for (int i = 0; i < 100; i++) {
            // Generate a random integer between -100 and 100
            int randomValue = random.nextInt(201) - 100;

            // Add the random value to the trueCount variable
            trueCount += randomValue;

            // Create a new noSynch object with the random value and add it to the vector
            noSynch thread = new noSynch(randomValue);
            vector.add(thread);

            // Start the thread
            thread.start();
        }

        // Create an iterator to iterate over the elements of the vector
        Iterator<noSynch> myIterator = vector.iterator();

        // Iterate through the vector
        while (myIterator.hasNext()) {
            try {
                // Wait for each thread to finish execution using join()
                myIterator.next().join();
            } catch (InterruptedException e) {
                // Handle interrupted exception
                e.printStackTrace();
            }
        }

        // Print the trueCount and the total from the noSynch class to show differences in the counts
        System.out.println("Actual count is " + trueCount);
        System.out.println("Unsynchronized count is " + noSynch.getTotal());

        // completion of Part 1 and the start of Part 2
        System.out.println("\nPart One is complete, starting part Two\n");


        // Part Two of the program
        progState state = new progState(); // Create an instance of progState to track object counts
        Vector<Thread> vec = new Vector<>(); // Create a vector to hold threads

        System.out.println("PART 2 \n"); // Print a message stating the start of Part Two

        Scanner scanner = new Scanner(System.in); // Create a Scanner object to read user input
        System.out.println("Please enter a path to an input file: "); // Prompt user to enter file path or file name
        String filePath = scanner.nextLine(); // Read the file path entered by the user

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) { // Try to open the file for reading
            String line;
            while ((line = br.readLine()) != null) { // Read each line of the file
                String[] parts = line.split(" "); // Split the line by space
                if (parts.length == 2) { // if the line has exactly two parts
                    String className = parts[0]; // Extract the class name from the first part
                    long sleepTime = Long.parseLong(parts[1]); // Extract the sleep time from the second part

                    Thread t; // Declare a Thread object
                    switch (className) { // Check the class name to see what the class is
                        case "A": // If class name is "A"
                            t = new Aclass(state, sleepTime); // Create a new Aclass thread
                            break;
                        case "B": // If class name is "B"
                            t = new Bclass(state, sleepTime); // Create a new Bclass thread
                            break;
                        case "C": // If class name is "C"
                            t = new Thread(new Cclass(state, sleepTime)); // Create a new Thread with Cclass object as Runnable
                            break;
                        case "D": // If class name is "D"
                            t = new Thread(new Dclass(state, sleepTime)); // Create a new Thread with Dclass object as Runnable
                            break;
                        case "P": // If class name is "P" we are told to call the printTotal()
                            //method of the progState object to print out a list of the current total count and individual
                            //counts of the four thread classes (classA, classB, classC, classD).
                            state.printTotal(); // Print total counts
                            continue; // Continue to the next iteration
                        default: // If class name is invalid
                            continue; // Continue to the next iteration
                    }
                    vec.add(t); // Add the created thread to the vector
                    t.start(); // Start the thread
                }
            }

            // Wait for all threads to complete
            Iterator<Thread> iterate = vec.iterator(); // Create an iterator for the vector
            while (iterate.hasNext()) { // While there are more threads in the vector
                try {
                    iterate.next().join(); // Wait for the thread to complete
                } catch (InterruptedException e) {
                    e.printStackTrace(); // Print stack trace if interrupted
                }
            }
        } catch (IOException e) { // Catch IOException
            e.printStackTrace(); // Print stack trace if an error occurs while reading the file
        }

        System.out.println("\nPart two is complete, starting part Three now\n");
        // Print a message about the completion of Part Two and the start of Part Three


        // Part Three
        Vector<myProcess> processes = new Vector<>(); // Vector to store myProcess objects
        myCounter counter = null; // Initialize myCounter object to null

        System.out.println("Please enter a path to an input file: ");
        filePath = scanner.nextLine(); // Read file path from user input

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) { // Try to read from file
            int startingValue = Integer.parseInt(br.readLine()); // Read starting value for myCounter
            counter = new myCounter(startingValue); // Initialize myCounter object with starting value

            String line;
            int threadNum = 20; // Start thread numbering from 20
            while ((line = br.readLine()) != null) { // Read each line from file
                long time_to_sleep = Long.parseLong(line); // Parse line to get sleep time
                myProcess process = new myProcess(counter, time_to_sleep); // Create new myProcess object
                process.setName("Thread-" + threadNum++); // Set name for the thread
                processes.add(process); // Add process to vector
                process.start(); // Start the thread
            }
        } catch (IOException e) { // Handle file reading errors
            e.printStackTrace();
        }

        // Join all myProcess threads
        for (int i = 0; i < processes.size(); i++) {
            myProcess process = processes.get(i);
            try {
                process.join();
            } catch (InterruptedException e) {
                // Handle InterruptedException
                e.printStackTrace();
            }
        }

        // Print final counter value
        if (counter != null) {
            System.out.println("FINAL Counter value is " + counter.getTotal());
        } else { // if error
            System.out.println("No counter object created.");
        }

        // Print completion message finsihed the program
        System.out.println("\nYou have finished your program, which is not three separate programs but one program. Thank you, have a good day!");
    }
}
