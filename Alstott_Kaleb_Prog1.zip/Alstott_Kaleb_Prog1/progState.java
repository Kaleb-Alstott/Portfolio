public class progState {
    // Private data types to store counts for all classes and totalObjects
    private int totalObjects;
    private int Acount;
    private int Bcount;
    private int Ccount;
    private int Dcount;

    // Constructor to initialize counts to 0 for all totalObjects and class count
    public progState() {
        totalObjects = 0;
        Acount = 0;
        Bcount = 0;
        Ccount = 0;
        Dcount = 0;
    }

    // Synchronized method to increment count of class A objects
    public synchronized void incA() {
        Acount++;
        totalObjects++;
    }

    // Synchronized method to decrement count of class A objects
    public synchronized void decA() {
        Acount--;
    }

    // Synchronized method to increment count of class B objects
    public synchronized void incB() {
        Bcount++;
        totalObjects++;
    }

    // Synchronized method to decrement count of class B objects
    public synchronized void decB() {
        Bcount--;
    }

    // Synchronized method to increment count of class C objects
    public synchronized void incC() {
        Ccount++;
        totalObjects++;
    }

    // Synchronized method to decrement count of class C objects
    public synchronized void decC() {
        Ccount--;
    }

    // Synchronized method to increment count of class D objects
    public synchronized void incD() {
        Dcount++;
        totalObjects++;
    }

    // Synchronized method to decrement count of class D objects
    public synchronized void decD() {
        Dcount--;
    }

    // Synchronized method to print total counts of all classes
    public synchronized void printTotal() {
        // Calculate total count of all classes
        int total = Acount + Bcount + Ccount + Dcount;
        synchronized (System.out) { // synchronized block
            // Print total count and counts for each class
            System.out.println("Total is " + total);
            System.out.println("***************");
            System.out.println(Acount + " Class A Objects");
            System.out.println(Bcount + " Class B Objects");
            System.out.println(Ccount + " Class C Objects");
            System.out.println(Dcount + " Class D Objects");
            System.out.println("***************\n");
            System.out.flush(); // Flush the output stream
        }
    }
}
