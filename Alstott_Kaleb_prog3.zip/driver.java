import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class driver {
    public static void main(String[] args) {
        // part A start
        System.out.println("\nPart A - OUTPUT");
        System.out.println("*****************\n");

        // create our fixed thread pool of 8 threads
        ExecutorService executorService = Executors.newFixedThreadPool(8);
        // our list to store our futures
        List<Future<?>> myFutures = new ArrayList<>();

        // submit our 135 sampleThread tasks to the executor service
        for (int i = 0; i < 135; i++) {
            sampleThread sampleThread = new sampleThread(i);
            // submit the task and add future to the list
            Future<?> future = executorService.submit(sampleThread);
            myFutures.add(future);
        }

        // wait for all threads to complete
        for (Future<?> currentFuture : myFutures) {
            try {
                currentFuture.get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }

        // shutdown the executor service
        executorService.shutdown();

        // Part B starting
        System.out.println("\nPart B - OUTPUT");
        System.out.println("*****************\n");

        // create our cached thread pool
        ExecutorService cachedExecutor = Executors.newCachedThreadPool();
        // list to store integer of futures
        List<Future<Integer>> myIntegerFutures = new ArrayList<>();

        //  613 sampleCallable tasks created to the cached executor
        for (int i = 0; i < 613; i++) {
            sampleCallable sampleCallable1 = new sampleCallable(i);
            // submit the task and add the future to the list
            Future<Integer> futureToo = cachedExecutor.submit(sampleCallable1);
            myIntegerFutures.add(futureToo);
        }

        // print results from future
        for (int i = 0; i < myIntegerFutures.size(); i++) {
            try {
                //get result from the future to be able to print out thread
                Integer result = myIntegerFutures.get(i).get();
                // print sampleCallable name and result that has returned
                System.out.println("sampleCallable" + i + " has returned " + result);
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }

        // shutdown the cached executor
        cachedExecutor.shutdown();

        // sleep for 1000 milliseconds before we end program
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // end of program
        System.out.println("\nEND OF EXECUTION. Thank you and try again!");
    }
}

/*
Part A - OUTPUT
*****************

Thread4 sleeping for 201 milliseconds.
Thread5 sleeping for 45 milliseconds.
Thread7 sleeping for 384 milliseconds.
Thread6 sleeping for 170 milliseconds.
Thread2 sleeping for 229 milliseconds.
Thread3 sleeping for 496 milliseconds.
Thread0 sleeping for 464 milliseconds.
Thread1 sleeping for 205 milliseconds.
Thread5 is awake.
Thread8 sleeping for 84 milliseconds.
Thread8 is awake.
Thread9 sleeping for 17 milliseconds.
Thread6 is awake.
Thread10 sleeping for 332 milliseconds.
Thread9 is awake.
Thread11 sleeping for 378 milliseconds.
Thread4 is awake.
Thread12 sleeping for 205 milliseconds.
Thread1 is awake.
Thread13 sleeping for 199 milliseconds.
Thread2 is awake.
Thread14 sleeping for 45 milliseconds.
Thread14 is awake.
Thread15 sleeping for 401 milliseconds.
Thread7 is awake.
Thread16 sleeping for 246 milliseconds.
Thread12 is awake.
Thread17 sleeping for 26 milliseconds.
Thread13 is awake.
Thread18 sleeping for 330 milliseconds.
Thread17 is awake.
Thread19 sleeping for 35 milliseconds.
Thread0 is awake.
Thread20 sleeping for 119 milliseconds.
Thread19 is awake.
Thread21 sleeping for 99 milliseconds.
Thread3 is awake.
Thread22 sleeping for 334 milliseconds.
Thread10 is awake.
Thread23 sleeping for 411 milliseconds.
Thread11 is awake.
Thread24 sleeping for 475 milliseconds.
Thread21 is awake.
Thread25 sleeping for 206 milliseconds.
Thread20 is awake.
Thread26 sleeping for 472 milliseconds.
Thread16 is awake.
Thread27 sleeping for 260 milliseconds.
Thread15 is awake.
Thread28 sleeping for 251 milliseconds.
Thread18 is awake.
Thread29 sleeping for 481 milliseconds.
Thread25 is awake.
Thread30 sleeping for 211 milliseconds.
Thread22 is awake.
Thread31 sleeping for 70 milliseconds.
Thread27 is awake.
Thread32 sleeping for 374 milliseconds.
Thread31 is awake.
Thread33 sleeping for 3 milliseconds.
Thread23 is awake.
Thread33 is awake.
Thread34 sleeping for 414 milliseconds.
Thread35 sleeping for 107 milliseconds.
Thread28 is awake.
Thread36 sleeping for 214 milliseconds.
Thread30 is awake.
Thread37 sleeping for 171 milliseconds.
Thread35 is awake.
Thread38 sleeping for 380 milliseconds.
Thread24 is awake.
Thread39 sleeping for 170 milliseconds.
Thread26 is awake.
Thread40 sleeping for 247 milliseconds.
Thread36 is awake.
Thread41 sleeping for 286 milliseconds.
Thread37 is awake.
Thread42 sleeping for 302 milliseconds.
Thread39 is awake.
Thread43 sleeping for 253 milliseconds.
Thread29 is awake.
Thread44 sleeping for 214 milliseconds.
Thread32 is awake.
Thread45 sleeping for 363 milliseconds.
Thread40 is awake.
Thread46 sleeping for 216 milliseconds.
Thread34 is awake.
Thread47 sleeping for 143 milliseconds.
Thread38 is awake.
Thread48 sleeping for 311 milliseconds.
Thread41 is awake.
Thread49 sleeping for 335 milliseconds.
Thread44 is awake.
Thread50 sleeping for 221 milliseconds.
Thread43 is awake.
Thread51 sleeping for 40 milliseconds.
Thread42 is awake.
Thread52 sleeping for 206 milliseconds.
Thread47 is awake.
Thread53 sleeping for 359 milliseconds.
Thread51 is awake.
Thread54 sleeping for 264 milliseconds.
Thread46 is awake.
Thread55 sleeping for 102 milliseconds.
Thread45 is awake.
Thread56 sleeping for 4 milliseconds.
Thread55 is awake.
Thread57 sleeping for 292 milliseconds.
Thread56 is awake.
Thread58 sleeping for 257 milliseconds.
Thread50 is awake.
Thread59 sleeping for 291 milliseconds.
Thread52 is awake.
Thread60 sleeping for 331 milliseconds.
Thread48 is awake.
Thread61 sleeping for 425 milliseconds.
Thread54 is awake.
Thread62 sleeping for 430 milliseconds.
Thread49 is awake.
Thread63 sleeping for 2 milliseconds.
Thread63 is awake.
Thread64 sleeping for 275 milliseconds.
Thread53 is awake.
Thread65 sleeping for 74 milliseconds.
Thread58 is awake.
Thread66 sleeping for 23 milliseconds.
Thread65 is awake.
Thread67 sleeping for 176 milliseconds.
Thread66 is awake.
Thread68 sleeping for 493 milliseconds.
Thread57 is awake.
Thread69 sleeping for 218 milliseconds.
Thread59 is awake.
Thread70 sleeping for 457 milliseconds.
Thread60 is awake.
Thread71 sleeping for 414 milliseconds.
Thread64 is awake.
Thread72 sleeping for 229 milliseconds.
Thread67 is awake.
Thread73 sleeping for 417 milliseconds.
Thread61 is awake.
Thread74 sleeping for 275 milliseconds.
Thread69 is awake.
Thread75 sleeping for 470 milliseconds.
Thread62 is awake.
Thread76 sleeping for 193 milliseconds.
Thread72 is awake.
Thread77 sleeping for 114 milliseconds.
Thread77 is awake.
Thread78 sleeping for 325 milliseconds.
Thread76 is awake.
Thread79 sleeping for 141 milliseconds.
Thread70 is awake.
Thread80 sleeping for 250 milliseconds.
Thread68 is awake.
Thread81 sleeping for 492 milliseconds.
Thread74 is awake.
Thread82 sleeping for 112 milliseconds.
Thread71 is awake.
Thread83 sleeping for 218 milliseconds.
Thread73 is awake.
Thread84 sleeping for 483 milliseconds.
Thread82 is awake.
Thread85 sleeping for 35 milliseconds.
Thread79 is awake.
Thread86 sleeping for 374 milliseconds.
Thread85 is awake.
Thread87 sleeping for 344 milliseconds.
Thread75 is awake.
Thread88 sleeping for 190 milliseconds.
Thread83 is awake.
Thread89 sleeping for 360 milliseconds.
Thread80 is awake.
Thread90 sleeping for 143 milliseconds.
Thread78 is awake.
Thread91 sleeping for 415 milliseconds.
Thread90 is awake.
Thread92 sleeping for 176 milliseconds.
Thread88 is awake.
Thread93 sleeping for 153 milliseconds.
Thread81 is awake.
Thread94 sleeping for 352 milliseconds.
Thread86 is awake.
Thread95 sleeping for 187 milliseconds.
Thread87 is awake.
Thread96 sleeping for 245 milliseconds.
Thread93 is awake.
Thread97 sleeping for 20 milliseconds.
Thread92 is awake.
Thread98 sleeping for 248 milliseconds.
Thread97 is awake.
Thread99 sleeping for 392 milliseconds.
Thread84 is awake.
Thread100 sleeping for 311 milliseconds.
Thread89 is awake.
Thread101 sleeping for 352 milliseconds.
Thread95 is awake.
Thread102 sleeping for 8 milliseconds.
Thread102 is awake.
Thread103 sleeping for 73 milliseconds.
Thread91 is awake.
Thread104 sleeping for 414 milliseconds.
Thread96 is awake.
Thread105 sleeping for 170 milliseconds.
Thread103 is awake.
Thread106 sleeping for 470 milliseconds.
Thread98 is awake.
Thread107 sleeping for 72 milliseconds.
Thread94 is awake.
Thread108 sleeping for 102 milliseconds.
Thread107 is awake.
Thread109 sleeping for 344 milliseconds.
Thread100 is awake.
Thread110 sleeping for 460 milliseconds.
Thread105 is awake.
Thread111 sleeping for 314 milliseconds.
Thread101 is awake.
Thread112 sleeping for 42 milliseconds.
Thread108 is awake.
Thread113 sleeping for 22 milliseconds.
Thread99 is awake.
Thread114 sleeping for 496 milliseconds.
Thread113 is awake.
Thread115 sleeping for 327 milliseconds.
Thread112 is awake.
Thread116 sleeping for 342 milliseconds.
Thread104 is awake.
Thread117 sleeping for 393 milliseconds.
Thread109 is awake.
Thread111 is awake.
Thread118 sleeping for 384 milliseconds.
Thread119 sleeping for 142 milliseconds.
Thread106 is awake.
Thread120 sleeping for 364 milliseconds.
Thread115 is awake.
Thread121 sleeping for 447 milliseconds.
Thread116 is awake.
Thread122 sleeping for 77 milliseconds.
Thread110 is awake.
Thread123 sleeping for 496 milliseconds.
Thread119 is awake.
Thread124 sleeping for 360 milliseconds.
Thread122 is awake.
Thread125 sleeping for 275 milliseconds.
Thread114 is awake.
Thread126 sleeping for 175 milliseconds.
Thread117 is awake.
Thread127 sleeping for 102 milliseconds.
Thread120 is awake.
Thread128 sleeping for 408 milliseconds.
Thread118 is awake.
Thread129 sleeping for 269 milliseconds.
Thread127 is awake.
Thread130 sleeping for 216 milliseconds.
Thread126 is awake.
Thread131 sleeping for 474 milliseconds.
Thread125 is awake.
Thread132 sleeping for 292 milliseconds.
Thread124 is awake.
Thread133 sleeping for 142 milliseconds.
Thread121 is awake.
Thread134 sleeping for 45 milliseconds.
Thread134 is awake.
Thread130 is awake.
Thread123 is awake.
Thread133 is awake.
Thread129 is awake.
Thread132 is awake.
Thread128 is awake.
Thread131 is awake.

Part B - OUTPUT
*****************

Thread-12 calculating square of 8
Thread-14 calculating square of 18
Thread-6 calculating square of 53
Thread-15 calculating square of 16
Thread-7 calculating square of 39
Thread-5 calculating square of 15
Thread-8 calculating square of 90
Thread-0 calculating square of 96
Thread-9 calculating square of 18
Thread-13 calculating square of 80
Thread-16 calculating square of 85
Thread-2 calculating square of 1
Thread-1 calculating square of 48
Thread-3 calculating square of 79
Thread-11 calculating square of 73
Thread-4 calculating square of 93
Thread-17 calculating square of 46
Thread-10 calculating square of 78
Thread-19 calculating square of 94
Thread-18 calculating square of 10
Thread-20 calculating square of 32
Thread-21 calculating square of 63
Thread-22 calculating square of 55
Thread-23 calculating square of 75
Thread-24 calculating square of 27
Thread-25 calculating square of 94
Thread-26 calculating square of 44
Thread-27 calculating square of 1
Thread-28 calculating square of 8
Thread-29 calculating square of 32
Thread-30 calculating square of 59
Thread-31 calculating square of 21
Thread-32 calculating square of 77
Thread-33 calculating square of 14
Thread-34 calculating square of 60
Thread-35 calculating square of 77
Thread-36 calculating square of 44
Thread-37 calculating square of 51
Thread-39 calculating square of 99
Thread-40 calculating square of 96
Thread-38 calculating square of 54
Thread-41 calculating square of 45
Thread-42 calculating square of 3
Thread-43 calculating square of 78
Thread-44 calculating square of 52
Thread-45 calculating square of 77
Thread-46 calculating square of 4
Thread-47 calculating square of 26
Thread-48 calculating square of 4
Thread-49 calculating square of 50
Thread-50 calculating square of 58
Thread-51 calculating square of 15
Thread-52 calculating square of 28
Thread-53 calculating square of 97
Thread-54 calculating square of 26
Thread-55 calculating square of 22
Thread-56 calculating square of 79
Thread-57 calculating square of 87
Thread-58 calculating square of 8
Thread-59 calculating square of 80
Thread-60 calculating square of 90
Thread-61 calculating square of 90
Thread-62 calculating square of 22
Thread-63 calculating square of 28
Thread-64 calculating square of 88
Thread-65 calculating square of 50
Thread-66 calculating square of 88
Thread-67 calculating square of 92
Thread-68 calculating square of 22
Thread-69 calculating square of 78
Thread-70 calculating square of 5
Thread-72 calculating square of 28
Thread-71 calculating square of 34
Thread-73 calculating square of 37
Thread-74 calculating square of 95
Thread-75 calculating square of 59
Thread-76 calculating square of 81
Thread-77 calculating square of 86
Thread-78 calculating square of 93
Thread-79 calculating square of 97
Thread-80 calculating square of 85
Thread-81 calculating square of 48
Thread-82 calculating square of 99
Thread-83 calculating square of 61
Thread-84 calculating square of 82
Thread-85 calculating square of 80
Thread-86 calculating square of 55
Thread-87 calculating square of 32
Thread-88 calculating square of 76
Thread-89 calculating square of 24
Thread-90 calculating square of 12
Thread-91 calculating square of 98
Thread-92 calculating square of 29
Thread-93 calculating square of 92
Thread-94 calculating square of 49
Thread-95 calculating square of 49
Thread-96 calculating square of 10
Thread-97 calculating square of 41
Thread-98 calculating square of 52
Thread-99 calculating square of 29
Thread-100 calculating square of 92
Thread-101 calculating square of 26
Thread-102 calculating square of 60
Thread-103 calculating square of 4
Thread-104 calculating square of 18
Thread-105 calculating square of 15
Thread-106 calculating square of 26
Thread-108 calculating square of 66
Thread-107 calculating square of 32
Thread-109 calculating square of 85
Thread-110 calculating square of 63
Thread-111 calculating square of 4
Thread-112 calculating square of 78
Thread-113 calculating square of 95
Thread-114 calculating square of 19
Thread-115 calculating square of 71
Thread-116 calculating square of 48
Thread-117 calculating square of 21
Thread-118 calculating square of 96
Thread-119 calculating square of 69
Thread-120 calculating square of 15
Thread-121 calculating square of 15
Thread-122 calculating square of 52
Thread-123 calculating square of 65
Thread-124 calculating square of 18
Thread-125 calculating square of 61
Thread-126 calculating square of 12
Thread-127 calculating square of 41
Thread-128 calculating square of 71
Thread-129 calculating square of 15
Thread-130 calculating square of 5
Thread-131 calculating square of 5
Thread-132 calculating square of 36
Thread-133 calculating square of 50
Thread-134 calculating square of 57
Thread-135 calculating square of 47
Thread-136 calculating square of 35
Thread-137 calculating square of 44
Thread-138 calculating square of 27
Thread-139 calculating square of 71
Thread-140 calculating square of 78
Thread-141 calculating square of 6
Thread-142 calculating square of 34
Thread-143 calculating square of 91
Thread-144 calculating square of 95
Thread-145 calculating square of 21
Thread-146 calculating square of 65
Thread-147 calculating square of 96
Thread-148 calculating square of 83
Thread-149 calculating square of 62
Thread-150 calculating square of 84
Thread-151 calculating square of 24
Thread-152 calculating square of 49
Thread-153 calculating square of 6
Thread-154 calculating square of 64
Thread-155 calculating square of 24
Thread-156 calculating square of 26
Thread-157 calculating square of 64
Thread-158 calculating square of 54
Thread-159 calculating square of 54
Thread-160 calculating square of 57
Thread-161 calculating square of 28
Thread-162 calculating square of 66
Thread-163 calculating square of 84
Thread-164 calculating square of 65
Thread-165 calculating square of 86
Thread-166 calculating square of 17
Thread-167 calculating square of 1
Thread-168 calculating square of 16
Thread-169 calculating square of 51
Thread-170 calculating square of 30
Thread-171 calculating square of 30
Thread-172 calculating square of 62
Thread-173 calculating square of 83
Thread-174 calculating square of 74
Thread-175 calculating square of 59
Thread-176 calculating square of 84
Thread-177 calculating square of 74
Thread-178 calculating square of 42
Thread-179 calculating square of 10
Thread-180 calculating square of 92
Thread-181 calculating square of 14
Thread-182 calculating square of 93
Thread-183 calculating square of 61
Thread-184 calculating square of 84
Thread-185 calculating square of 52
Thread-186 calculating square of 1
Thread-187 calculating square of 52
Thread-188 calculating square of 88
Thread-189 calculating square of 99
Thread-190 calculating square of 54
Thread-191 calculating square of 23
Thread-192 calculating square of 97
Thread-193 calculating square of 87
Thread-194 calculating square of 33
Thread-195 calculating square of 76
Thread-196 calculating square of 59
Thread-197 calculating square of 84
Thread-198 calculating square of 24
Thread-199 calculating square of 26
Thread-200 calculating square of 6
Thread-201 calculating square of 7
Thread-202 calculating square of 14
Thread-203 calculating square of 17
Thread-204 calculating square of 98
Thread-205 calculating square of 72
Thread-206 calculating square of 66
Thread-207 calculating square of 19
Thread-208 calculating square of 17
Thread-209 calculating square of 33
Thread-210 calculating square of 59
Thread-211 calculating square of 90
Thread-212 calculating square of 93
Thread-213 calculating square of 9
Thread-214 calculating square of 94
Thread-215 calculating square of 81
Thread-216 calculating square of 2
Thread-217 calculating square of 60
Thread-218 calculating square of 14
Thread-219 calculating square of 97
Thread-220 calculating square of 34
Thread-221 calculating square of 76
Thread-222 calculating square of 59
Thread-223 calculating square of 81
Thread-224 calculating square of 16
Thread-225 calculating square of 32
Thread-226 calculating square of 89
Thread-227 calculating square of 61
Thread-228 calculating square of 84
Thread-229 calculating square of 19
Thread-230 calculating square of 45
Thread-231 calculating square of 14
Thread-232 calculating square of 81
Thread-233 calculating square of 30
Thread-234 calculating square of 76
Thread-235 calculating square of 17
Thread-236 calculating square of 57
Thread-237 calculating square of 9
Thread-238 calculating square of 70
Thread-239 calculating square of 16
Thread-240 calculating square of 33
Thread-241 calculating square of 3
Thread-242 calculating square of 45
Thread-243 calculating square of 45
Thread-244 calculating square of 55
Thread-245 calculating square of 83
Thread-246 calculating square of 97
Thread-247 calculating square of 93
Thread-248 calculating square of 62
Thread-249 calculating square of 64
Thread-250 calculating square of 55
Thread-251 calculating square of 3
Thread-252 calculating square of 83
Thread-253 calculating square of 76
Thread-254 calculating square of 80
Thread-255 calculating square of 50
Thread-256 calculating square of 79
Thread-257 calculating square of 67
Thread-258 calculating square of 31
Thread-259 calculating square of 18
Thread-260 calculating square of 29
Thread-261 calculating square of 80
Thread-262 calculating square of 16
Thread-263 calculating square of 36
Thread-264 calculating square of 87
Thread-265 calculating square of 14
Thread-266 calculating square of 86
Thread-267 calculating square of 56
Thread-268 calculating square of 11
Thread-269 calculating square of 35
Thread-270 calculating square of 82
Thread-271 calculating square of 6
Thread-272 calculating square of 29
Thread-273 calculating square of 52
Thread-274 calculating square of 6
Thread-275 calculating square of 58
Thread-276 calculating square of 78
Thread-277 calculating square of 97
Thread-278 calculating square of 77
Thread-279 calculating square of 43
Thread-280 calculating square of 57
Thread-281 calculating square of 5
Thread-282 calculating square of 3
Thread-283 calculating square of 11
Thread-284 calculating square of 17
Thread-285 calculating square of 30
Thread-286 calculating square of 31
Thread-287 calculating square of 96
Thread-288 calculating square of 46
Thread-289 calculating square of 62
Thread-290 calculating square of 83
Thread-291 calculating square of 58
Thread-292 calculating square of 31
Thread-293 calculating square of 59
Thread-294 calculating square of 65
Thread-295 calculating square of 25
Thread-296 calculating square of 38
Thread-297 calculating square of 12
Thread-298 calculating square of 45
Thread-299 calculating square of 54
Thread-300 calculating square of 61
Thread-301 calculating square of 28
Thread-302 calculating square of 93
Thread-303 calculating square of 89
Thread-304 calculating square of 59
Thread-305 calculating square of 17
Thread-306 calculating square of 78
Thread-307 calculating square of 27
Thread-308 calculating square of 28
Thread-309 calculating square of 37
Thread-310 calculating square of 65
Thread-311 calculating square of 30
Thread-312 calculating square of 48
Thread-313 calculating square of 52
Thread-314 calculating square of 13
Thread-315 calculating square of 73
Thread-316 calculating square of 50
Thread-317 calculating square of 49
Thread-318 calculating square of 29
Thread-319 calculating square of 8
Thread-320 calculating square of 58
Thread-321 calculating square of 89
Thread-322 calculating square of 43
Thread-323 calculating square of 12
Thread-324 calculating square of 43
Thread-325 calculating square of 82
Thread-326 calculating square of 40
Thread-327 calculating square of 26
Thread-328 calculating square of 30
Thread-329 calculating square of 61
Thread-330 calculating square of 12
Thread-331 calculating square of 84
Thread-332 calculating square of 59
Thread-333 calculating square of 86
Thread-334 calculating square of 95
Thread-335 calculating square of 59
Thread-336 calculating square of 91
Thread-337 calculating square of 6
Thread-338 calculating square of 9
Thread-339 calculating square of 67
Thread-340 calculating square of 64
Thread-341 calculating square of 1
Thread-342 calculating square of 43
Thread-343 calculating square of 60
Thread-344 calculating square of 33
Thread-345 calculating square of 26
Thread-346 calculating square of 2
Thread-347 calculating square of 50
Thread-348 calculating square of 89
Thread-349 calculating square of 79
Thread-350 calculating square of 78
Thread-351 calculating square of 87
Thread-352 calculating square of 12
Thread-353 calculating square of 73
Thread-354 calculating square of 100
Thread-355 calculating square of 50
Thread-356 calculating square of 80
Thread-357 calculating square of 53
Thread-358 calculating square of 38
Thread-359 calculating square of 9
Thread-360 calculating square of 69
Thread-361 calculating square of 65
Thread-362 calculating square of 23
Thread-363 calculating square of 60
Thread-364 calculating square of 89
Thread-365 calculating square of 75
Thread-366 calculating square of 56
Thread-367 calculating square of 56
Thread-368 calculating square of 82
Thread-369 calculating square of 73
Thread-370 calculating square of 78
Thread-371 calculating square of 89
Thread-372 calculating square of 65
Thread-373 calculating square of 45
Thread-374 calculating square of 35
Thread-375 calculating square of 38
Thread-376 calculating square of 89
Thread-377 calculating square of 34
Thread-378 calculating square of 80
Thread-379 calculating square of 56
Thread-380 calculating square of 50
Thread-381 calculating square of 5
Thread-382 calculating square of 3
Thread-383 calculating square of 75
Thread-384 calculating square of 60
Thread-385 calculating square of 63
Thread-386 calculating square of 22
Thread-387 calculating square of 26
Thread-388 calculating square of 13
Thread-389 calculating square of 64
Thread-390 calculating square of 48
Thread-391 calculating square of 99
Thread-392 calculating square of 49
Thread-393 calculating square of 53
Thread-394 calculating square of 38
Thread-395 calculating square of 69
Thread-396 calculating square of 88
Thread-397 calculating square of 36
Thread-398 calculating square of 68
Thread-399 calculating square of 19
Thread-400 calculating square of 47
Thread-401 calculating square of 18
Thread-402 calculating square of 36
Thread-403 calculating square of 35
Thread-404 calculating square of 71
Thread-405 calculating square of 94
Thread-406 calculating square of 92
Thread-407 calculating square of 93
Thread-408 calculating square of 65
Thread-409 calculating square of 79
Thread-410 calculating square of 6
Thread-411 calculating square of 87
Thread-412 calculating square of 95
Thread-413 calculating square of 49
Thread-414 calculating square of 83
Thread-415 calculating square of 49
Thread-416 calculating square of 17
Thread-417 calculating square of 67
Thread-418 calculating square of 54
Thread-419 calculating square of 78
Thread-420 calculating square of 72
Thread-421 calculating square of 59
Thread-422 calculating square of 88
Thread-423 calculating square of 85
Thread-424 calculating square of 19
Thread-425 calculating square of 70
Thread-426 calculating square of 83
Thread-427 calculating square of 7
Thread-428 calculating square of 60
Thread-429 calculating square of 5
Thread-430 calculating square of 53
Thread-431 calculating square of 22
Thread-432 calculating square of 99
Thread-433 calculating square of 56
Thread-434 calculating square of 53
Thread-435 calculating square of 73
Thread-436 calculating square of 69
Thread-437 calculating square of 18
Thread-438 calculating square of 26
Thread-439 calculating square of 64
Thread-440 calculating square of 86
Thread-441 calculating square of 43
Thread-442 calculating square of 22
Thread-443 calculating square of 16
Thread-444 calculating square of 37
Thread-445 calculating square of 72
Thread-446 calculating square of 37
Thread-447 calculating square of 61
Thread-448 calculating square of 96
Thread-449 calculating square of 29
Thread-450 calculating square of 33
Thread-451 calculating square of 45
Thread-452 calculating square of 10
Thread-453 calculating square of 4
Thread-454 calculating square of 44
Thread-455 calculating square of 97
Thread-456 calculating square of 20
Thread-457 calculating square of 39
Thread-458 calculating square of 76
Thread-459 calculating square of 29
Thread-460 calculating square of 95
Thread-461 calculating square of 34
Thread-462 calculating square of 87
Thread-463 calculating square of 34
Thread-464 calculating square of 74
Thread-465 calculating square of 31
Thread-466 calculating square of 70
Thread-467 calculating square of 74
Thread-468 calculating square of 56
Thread-469 calculating square of 22
Thread-470 calculating square of 10
Thread-471 calculating square of 4
Thread-472 calculating square of 48
Thread-473 calculating square of 4
Thread-474 calculating square of 70
Thread-475 calculating square of 28
Thread-476 calculating square of 100
Thread-477 calculating square of 80
Thread-478 calculating square of 64
Thread-479 calculating square of 30
Thread-480 calculating square of 9
Thread-481 calculating square of 68
Thread-482 calculating square of 85
Thread-483 calculating square of 3
Thread-484 calculating square of 65
Thread-485 calculating square of 88
Thread-486 calculating square of 99
Thread-487 calculating square of 53
Thread-488 calculating square of 15
Thread-489 calculating square of 11
Thread-490 calculating square of 52
Thread-491 calculating square of 94
Thread-492 calculating square of 47
Thread-493 calculating square of 18
Thread-494 calculating square of 44
Thread-495 calculating square of 39
Thread-496 calculating square of 64
Thread-497 calculating square of 8
Thread-498 calculating square of 66
Thread-499 calculating square of 87
Thread-500 calculating square of 34
Thread-501 calculating square of 86
Thread-502 calculating square of 49
Thread-503 calculating square of 22
Thread-504 calculating square of 44
Thread-505 calculating square of 37
Thread-506 calculating square of 66
Thread-507 calculating square of 3
Thread-508 calculating square of 80
Thread-509 calculating square of 66
Thread-510 calculating square of 48
Thread-511 calculating square of 15
Thread-512 calculating square of 80
Thread-513 calculating square of 12
Thread-514 calculating square of 38
Thread-515 calculating square of 73
Thread-516 calculating square of 7
Thread-517 calculating square of 92
Thread-518 calculating square of 10
Thread-519 calculating square of 4
Thread-520 calculating square of 16
Thread-521 calculating square of 22
Thread-522 calculating square of 28
Thread-523 calculating square of 95
Thread-525 calculating square of 92
Thread-526 calculating square of 56
Thread-527 calculating square of 71
Thread-528 calculating square of 63
Thread-529 calculating square of 73
Thread-530 calculating square of 79
Thread-531 calculating square of 24
Thread-532 calculating square of 84
Thread-533 calculating square of 18
Thread-534 calculating square of 94
Thread-535 calculating square of 26
Thread-536 calculating square of 95
Thread-537 calculating square of 82
Thread-524 calculating square of 54
Thread-538 calculating square of 60
Thread-539 calculating square of 43
Thread-540 calculating square of 25
Thread-542 calculating square of 55
Thread-543 calculating square of 92
Thread-546 calculating square of 7
Thread-547 calculating square of 52
Thread-550 calculating square of 66
Thread-551 calculating square of 88
Thread-552 calculating square of 91
Thread-553 calculating square of 28
Thread-554 calculating square of 52
Thread-555 calculating square of 98
Thread-556 calculating square of 17
Thread-557 calculating square of 30
Thread-558 calculating square of 66
Thread-559 calculating square of 37
Thread-560 calculating square of 92
Thread-541 calculating square of 35
Thread-561 calculating square of 67
Thread-549 calculating square of 34
Thread-548 calculating square of 74
Thread-562 calculating square of 69
Thread-545 calculating square of 63
Thread-544 calculating square of 4
Thread-563 calculating square of 49
Thread-564 calculating square of 61
Thread-565 calculating square of 80
Thread-567 calculating square of 45
Thread-566 calculating square of 27
Thread-568 calculating square of 66
Thread-569 calculating square of 53
Thread-570 calculating square of 43
Thread-571 calculating square of 76
Thread-573 calculating square of 3
Thread-572 calculating square of 12
Thread-574 calculating square of 56
Thread-575 calculating square of 36
Thread-577 calculating square of 17
Thread-578 calculating square of 20
Thread-576 calculating square of 97
Thread-579 calculating square of 59
Thread-580 calculating square of 31
Thread-581 calculating square of 77
Thread-582 calculating square of 65
Thread-583 calculating square of 43
Thread-584 calculating square of 54
Thread-586 calculating square of 13
Thread-585 calculating square of 72
Thread-587 calculating square of 2
Thread-588 calculating square of 34
Thread-589 calculating square of 94
Thread-590 calculating square of 32
Thread-591 calculating square of 41
Thread-592 calculating square of 36
Thread-594 calculating square of 84
Thread-593 calculating square of 64
Thread-596 calculating square of 100
Thread-595 calculating square of 36
Thread-597 calculating square of 76
Thread-599 calculating square of 61
Thread-598 calculating square of 91
Thread-600 calculating square of 24
Thread-602 calculating square of 16
Thread-601 calculating square of 18
Thread-603 calculating square of 88
Thread-605 calculating square of 61
Thread-606 calculating square of 10
Thread-604 calculating square of 95
Thread-607 calculating square of 69
Thread-608 calculating square of 2
Thread-609 calculating square of 55
Thread-611 calculating square of 82
Thread-610 calculating square of 47
Thread-612 calculating square of 8
sampleCallable0 has returned 9216
sampleCallable1 has returned 2304
sampleCallable2 has returned 1
sampleCallable3 has returned 6241
sampleCallable4 has returned 8649
sampleCallable5 has returned 225
sampleCallable6 has returned 2809
sampleCallable7 has returned 1521
sampleCallable8 has returned 8100
sampleCallable9 has returned 324
sampleCallable10 has returned 6084
sampleCallable11 has returned 5329
sampleCallable12 has returned 64
sampleCallable13 has returned 6400
sampleCallable14 has returned 324
sampleCallable15 has returned 256
sampleCallable16 has returned 7225
sampleCallable17 has returned 2116
sampleCallable18 has returned 100
sampleCallable19 has returned 8836
sampleCallable20 has returned 1024
sampleCallable21 has returned 3969
sampleCallable22 has returned 3025
sampleCallable23 has returned 5625
sampleCallable24 has returned 729
sampleCallable25 has returned 8836
sampleCallable26 has returned 1936
sampleCallable27 has returned 1
sampleCallable28 has returned 64
sampleCallable29 has returned 1024
sampleCallable30 has returned 3481
sampleCallable31 has returned 441
sampleCallable32 has returned 5929
sampleCallable33 has returned 196
sampleCallable34 has returned 3600
sampleCallable35 has returned 5929
sampleCallable36 has returned 1936
sampleCallable37 has returned 2601
sampleCallable38 has returned 2916
sampleCallable39 has returned 9801
sampleCallable40 has returned 9216
sampleCallable41 has returned 2025
sampleCallable42 has returned 9
sampleCallable43 has returned 6084
sampleCallable44 has returned 2704
sampleCallable45 has returned 5929
sampleCallable46 has returned 16
sampleCallable47 has returned 676
sampleCallable48 has returned 16
sampleCallable49 has returned 2500
sampleCallable50 has returned 3364
sampleCallable51 has returned 225
sampleCallable52 has returned 784
sampleCallable53 has returned 9409
sampleCallable54 has returned 676
sampleCallable55 has returned 484
sampleCallable56 has returned 6241
sampleCallable57 has returned 7569
sampleCallable58 has returned 64
sampleCallable59 has returned 6400
sampleCallable60 has returned 8100
sampleCallable61 has returned 8100
sampleCallable62 has returned 484
sampleCallable63 has returned 784
sampleCallable64 has returned 7744
sampleCallable65 has returned 2500
sampleCallable66 has returned 7744
sampleCallable67 has returned 8464
sampleCallable68 has returned 484
sampleCallable69 has returned 6084
sampleCallable70 has returned 25
sampleCallable71 has returned 1156
sampleCallable72 has returned 784
sampleCallable73 has returned 1369
sampleCallable74 has returned 9025
sampleCallable75 has returned 3481
sampleCallable76 has returned 6561
sampleCallable77 has returned 7396
sampleCallable78 has returned 8649
sampleCallable79 has returned 9409
sampleCallable80 has returned 7225
sampleCallable81 has returned 2304
sampleCallable82 has returned 9801
sampleCallable83 has returned 3721
sampleCallable84 has returned 6724
sampleCallable85 has returned 6400
sampleCallable86 has returned 3025
sampleCallable87 has returned 1024
sampleCallable88 has returned 5776
sampleCallable89 has returned 576
sampleCallable90 has returned 144
sampleCallable91 has returned 9604
sampleCallable92 has returned 841
sampleCallable93 has returned 8464
sampleCallable94 has returned 2401
sampleCallable95 has returned 2401
sampleCallable96 has returned 100
sampleCallable97 has returned 1681
sampleCallable98 has returned 2704
sampleCallable99 has returned 841
sampleCallable100 has returned 8464
sampleCallable101 has returned 676
sampleCallable102 has returned 3600
sampleCallable103 has returned 16
sampleCallable104 has returned 324
sampleCallable105 has returned 225
sampleCallable106 has returned 676
sampleCallable107 has returned 1024
sampleCallable108 has returned 4356
sampleCallable109 has returned 7225
sampleCallable110 has returned 3969
sampleCallable111 has returned 16
sampleCallable112 has returned 6084
sampleCallable113 has returned 9025
sampleCallable114 has returned 361
sampleCallable115 has returned 5041
sampleCallable116 has returned 2304
sampleCallable117 has returned 441
sampleCallable118 has returned 9216
sampleCallable119 has returned 4761
sampleCallable120 has returned 225
sampleCallable121 has returned 225
sampleCallable122 has returned 2704
sampleCallable123 has returned 4225
sampleCallable124 has returned 324
sampleCallable125 has returned 3721
sampleCallable126 has returned 144
sampleCallable127 has returned 1681
sampleCallable128 has returned 5041
sampleCallable129 has returned 225
sampleCallable130 has returned 25
sampleCallable131 has returned 25
sampleCallable132 has returned 1296
sampleCallable133 has returned 2500
sampleCallable134 has returned 3249
sampleCallable135 has returned 2209
sampleCallable136 has returned 1225
sampleCallable137 has returned 1936
sampleCallable138 has returned 729
sampleCallable139 has returned 5041
sampleCallable140 has returned 6084
sampleCallable141 has returned 36
sampleCallable142 has returned 1156
sampleCallable143 has returned 8281
sampleCallable144 has returned 9025
sampleCallable145 has returned 441
sampleCallable146 has returned 4225
sampleCallable147 has returned 9216
sampleCallable148 has returned 6889
sampleCallable149 has returned 3844
sampleCallable150 has returned 7056
sampleCallable151 has returned 576
sampleCallable152 has returned 2401
sampleCallable153 has returned 36
sampleCallable154 has returned 4096
sampleCallable155 has returned 576
sampleCallable156 has returned 676
sampleCallable157 has returned 4096
sampleCallable158 has returned 2916
sampleCallable159 has returned 2916
sampleCallable160 has returned 3249
sampleCallable161 has returned 784
sampleCallable162 has returned 4356
sampleCallable163 has returned 7056
sampleCallable164 has returned 4225
sampleCallable165 has returned 7396
sampleCallable166 has returned 289
sampleCallable167 has returned 1
sampleCallable168 has returned 256
sampleCallable169 has returned 2601
sampleCallable170 has returned 900
sampleCallable171 has returned 900
sampleCallable172 has returned 3844
sampleCallable173 has returned 6889
sampleCallable174 has returned 5476
sampleCallable175 has returned 3481
sampleCallable176 has returned 7056
sampleCallable177 has returned 5476
sampleCallable178 has returned 1764
sampleCallable179 has returned 100
sampleCallable180 has returned 8464
sampleCallable181 has returned 196
sampleCallable182 has returned 8649
sampleCallable183 has returned 3721
sampleCallable184 has returned 7056
sampleCallable185 has returned 2704
sampleCallable186 has returned 1
sampleCallable187 has returned 2704
sampleCallable188 has returned 7744
sampleCallable189 has returned 9801
sampleCallable190 has returned 2916
sampleCallable191 has returned 529
sampleCallable192 has returned 9409
sampleCallable193 has returned 7569
sampleCallable194 has returned 1089
sampleCallable195 has returned 5776
sampleCallable196 has returned 3481
sampleCallable197 has returned 7056
sampleCallable198 has returned 576
sampleCallable199 has returned 676
sampleCallable200 has returned 36
sampleCallable201 has returned 49
sampleCallable202 has returned 196
sampleCallable203 has returned 289
sampleCallable204 has returned 9604
sampleCallable205 has returned 5184
sampleCallable206 has returned 4356
sampleCallable207 has returned 361
sampleCallable208 has returned 289
sampleCallable209 has returned 1089
sampleCallable210 has returned 3481
sampleCallable211 has returned 8100
sampleCallable212 has returned 8649
sampleCallable213 has returned 81
sampleCallable214 has returned 8836
sampleCallable215 has returned 6561
sampleCallable216 has returned 4
sampleCallable217 has returned 3600
sampleCallable218 has returned 196
sampleCallable219 has returned 9409
sampleCallable220 has returned 1156
sampleCallable221 has returned 5776
sampleCallable222 has returned 3481
sampleCallable223 has returned 6561
sampleCallable224 has returned 256
sampleCallable225 has returned 1024
sampleCallable226 has returned 7921
sampleCallable227 has returned 3721
sampleCallable228 has returned 7056
sampleCallable229 has returned 361
sampleCallable230 has returned 2025
sampleCallable231 has returned 196
sampleCallable232 has returned 6561
sampleCallable233 has returned 900
sampleCallable234 has returned 5776
sampleCallable235 has returned 289
sampleCallable236 has returned 3249
sampleCallable237 has returned 81
sampleCallable238 has returned 4900
sampleCallable239 has returned 256
sampleCallable240 has returned 1089
sampleCallable241 has returned 9
sampleCallable242 has returned 2025
sampleCallable243 has returned 2025
sampleCallable244 has returned 3025
sampleCallable245 has returned 6889
sampleCallable246 has returned 9409
sampleCallable247 has returned 8649
sampleCallable248 has returned 3844
sampleCallable249 has returned 4096
sampleCallable250 has returned 3025
sampleCallable251 has returned 9
sampleCallable252 has returned 6889
sampleCallable253 has returned 5776
sampleCallable254 has returned 6400
sampleCallable255 has returned 2500
sampleCallable256 has returned 6241
sampleCallable257 has returned 4489
sampleCallable258 has returned 961
sampleCallable259 has returned 324
sampleCallable260 has returned 841
sampleCallable261 has returned 6400
sampleCallable262 has returned 256
sampleCallable263 has returned 1296
sampleCallable264 has returned 7569
sampleCallable265 has returned 196
sampleCallable266 has returned 7396
sampleCallable267 has returned 3136
sampleCallable268 has returned 121
sampleCallable269 has returned 1225
sampleCallable270 has returned 6724
sampleCallable271 has returned 36
sampleCallable272 has returned 841
sampleCallable273 has returned 2704
sampleCallable274 has returned 36
sampleCallable275 has returned 3364
sampleCallable276 has returned 6084
sampleCallable277 has returned 9409
sampleCallable278 has returned 5929
sampleCallable279 has returned 1849
sampleCallable280 has returned 3249
sampleCallable281 has returned 25
sampleCallable282 has returned 9
sampleCallable283 has returned 121
sampleCallable284 has returned 289
sampleCallable285 has returned 900
sampleCallable286 has returned 961
sampleCallable287 has returned 9216
sampleCallable288 has returned 2116
sampleCallable289 has returned 3844
sampleCallable290 has returned 6889
sampleCallable291 has returned 3364
sampleCallable292 has returned 961
sampleCallable293 has returned 3481
sampleCallable294 has returned 4225
sampleCallable295 has returned 625
sampleCallable296 has returned 1444
sampleCallable297 has returned 144
sampleCallable298 has returned 2025
sampleCallable299 has returned 2916
sampleCallable300 has returned 3721
sampleCallable301 has returned 784
sampleCallable302 has returned 8649
sampleCallable303 has returned 7921
sampleCallable304 has returned 3481
sampleCallable305 has returned 289
sampleCallable306 has returned 6084
sampleCallable307 has returned 729
sampleCallable308 has returned 784
sampleCallable309 has returned 1369
sampleCallable310 has returned 4225
sampleCallable311 has returned 900
sampleCallable312 has returned 2304
sampleCallable313 has returned 2704
sampleCallable314 has returned 169
sampleCallable315 has returned 5329
sampleCallable316 has returned 2500
sampleCallable317 has returned 2401
sampleCallable318 has returned 841
sampleCallable319 has returned 64
sampleCallable320 has returned 3364
sampleCallable321 has returned 7921
sampleCallable322 has returned 1849
sampleCallable323 has returned 144
sampleCallable324 has returned 1849
sampleCallable325 has returned 6724
sampleCallable326 has returned 1600
sampleCallable327 has returned 676
sampleCallable328 has returned 900
sampleCallable329 has returned 3721
sampleCallable330 has returned 144
sampleCallable331 has returned 7056
sampleCallable332 has returned 3481
sampleCallable333 has returned 7396
sampleCallable334 has returned 9025
sampleCallable335 has returned 3481
sampleCallable336 has returned 8281
sampleCallable337 has returned 36
sampleCallable338 has returned 81
sampleCallable339 has returned 4489
sampleCallable340 has returned 4096
sampleCallable341 has returned 1
sampleCallable342 has returned 1849
sampleCallable343 has returned 3600
sampleCallable344 has returned 1089
sampleCallable345 has returned 676
sampleCallable346 has returned 4
sampleCallable347 has returned 2500
sampleCallable348 has returned 7921
sampleCallable349 has returned 6241
sampleCallable350 has returned 6084
sampleCallable351 has returned 7569
sampleCallable352 has returned 144
sampleCallable353 has returned 5329
sampleCallable354 has returned 10000
sampleCallable355 has returned 2500
sampleCallable356 has returned 6400
sampleCallable357 has returned 2809
sampleCallable358 has returned 1444
sampleCallable359 has returned 81
sampleCallable360 has returned 4761
sampleCallable361 has returned 4225
sampleCallable362 has returned 529
sampleCallable363 has returned 3600
sampleCallable364 has returned 7921
sampleCallable365 has returned 5625
sampleCallable366 has returned 3136
sampleCallable367 has returned 3136
sampleCallable368 has returned 6724
sampleCallable369 has returned 5329
sampleCallable370 has returned 6084
sampleCallable371 has returned 7921
sampleCallable372 has returned 4225
sampleCallable373 has returned 2025
sampleCallable374 has returned 1225
sampleCallable375 has returned 1444
sampleCallable376 has returned 7921
sampleCallable377 has returned 1156
sampleCallable378 has returned 6400
sampleCallable379 has returned 3136
sampleCallable380 has returned 2500
sampleCallable381 has returned 25
sampleCallable382 has returned 9
sampleCallable383 has returned 5625
sampleCallable384 has returned 3600
sampleCallable385 has returned 3969
sampleCallable386 has returned 484
sampleCallable387 has returned 676
sampleCallable388 has returned 169
sampleCallable389 has returned 4096
sampleCallable390 has returned 2304
sampleCallable391 has returned 9801
sampleCallable392 has returned 2401
sampleCallable393 has returned 2809
sampleCallable394 has returned 1444
sampleCallable395 has returned 4761
sampleCallable396 has returned 7744
sampleCallable397 has returned 1296
sampleCallable398 has returned 4624
sampleCallable399 has returned 361
sampleCallable400 has returned 2209
sampleCallable401 has returned 324
sampleCallable402 has returned 1296
sampleCallable403 has returned 1225
sampleCallable404 has returned 5041
sampleCallable405 has returned 8836
sampleCallable406 has returned 8464
sampleCallable407 has returned 8649
sampleCallable408 has returned 4225
sampleCallable409 has returned 6241
sampleCallable410 has returned 36
sampleCallable411 has returned 7569
sampleCallable412 has returned 9025
sampleCallable413 has returned 2401
sampleCallable414 has returned 6889
sampleCallable415 has returned 2401
sampleCallable416 has returned 289
sampleCallable417 has returned 4489
sampleCallable418 has returned 2916
sampleCallable419 has returned 6084
sampleCallable420 has returned 5184
sampleCallable421 has returned 3481
sampleCallable422 has returned 7744
sampleCallable423 has returned 7225
sampleCallable424 has returned 361
sampleCallable425 has returned 4900
sampleCallable426 has returned 6889
sampleCallable427 has returned 49
sampleCallable428 has returned 3600
sampleCallable429 has returned 25
sampleCallable430 has returned 2809
sampleCallable431 has returned 484
sampleCallable432 has returned 9801
sampleCallable433 has returned 3136
sampleCallable434 has returned 2809
sampleCallable435 has returned 5329
sampleCallable436 has returned 4761
sampleCallable437 has returned 324
sampleCallable438 has returned 676
sampleCallable439 has returned 4096
sampleCallable440 has returned 7396
sampleCallable441 has returned 1849
sampleCallable442 has returned 484
sampleCallable443 has returned 256
sampleCallable444 has returned 1369
sampleCallable445 has returned 5184
sampleCallable446 has returned 1369
sampleCallable447 has returned 3721
sampleCallable448 has returned 9216
sampleCallable449 has returned 841
sampleCallable450 has returned 1089
sampleCallable451 has returned 2025
sampleCallable452 has returned 100
sampleCallable453 has returned 16
sampleCallable454 has returned 1936
sampleCallable455 has returned 9409
sampleCallable456 has returned 400
sampleCallable457 has returned 1521
sampleCallable458 has returned 5776
sampleCallable459 has returned 841
sampleCallable460 has returned 9025
sampleCallable461 has returned 1156
sampleCallable462 has returned 7569
sampleCallable463 has returned 1156
sampleCallable464 has returned 5476
sampleCallable465 has returned 961
sampleCallable466 has returned 4900
sampleCallable467 has returned 5476
sampleCallable468 has returned 3136
sampleCallable469 has returned 484
sampleCallable470 has returned 100
sampleCallable471 has returned 16
sampleCallable472 has returned 2304
sampleCallable473 has returned 16
sampleCallable474 has returned 4900
sampleCallable475 has returned 784
sampleCallable476 has returned 10000
sampleCallable477 has returned 6400
sampleCallable478 has returned 4096
sampleCallable479 has returned 900
sampleCallable480 has returned 81
sampleCallable481 has returned 4624
sampleCallable482 has returned 7225
sampleCallable483 has returned 9
sampleCallable484 has returned 4225
sampleCallable485 has returned 7744
sampleCallable486 has returned 9801
sampleCallable487 has returned 2809
sampleCallable488 has returned 225
sampleCallable489 has returned 121
sampleCallable490 has returned 2704
sampleCallable491 has returned 8836
sampleCallable492 has returned 2209
sampleCallable493 has returned 324
sampleCallable494 has returned 1936
sampleCallable495 has returned 1521
sampleCallable496 has returned 4096
sampleCallable497 has returned 64
sampleCallable498 has returned 4356
sampleCallable499 has returned 7569
sampleCallable500 has returned 1156
sampleCallable501 has returned 7396
sampleCallable502 has returned 2401
sampleCallable503 has returned 484
sampleCallable504 has returned 1936
sampleCallable505 has returned 1369
sampleCallable506 has returned 4356
sampleCallable507 has returned 9
sampleCallable508 has returned 6400
sampleCallable509 has returned 4356
sampleCallable510 has returned 2304
sampleCallable511 has returned 225
sampleCallable512 has returned 6400
sampleCallable513 has returned 144
sampleCallable514 has returned 1444
sampleCallable515 has returned 5329
sampleCallable516 has returned 49
sampleCallable517 has returned 8464
sampleCallable518 has returned 100
sampleCallable519 has returned 16
sampleCallable520 has returned 256
sampleCallable521 has returned 484
sampleCallable522 has returned 784
sampleCallable523 has returned 9025
sampleCallable524 has returned 2916
sampleCallable525 has returned 8464
sampleCallable526 has returned 3136
sampleCallable527 has returned 5041
sampleCallable528 has returned 3969
sampleCallable529 has returned 5329
sampleCallable530 has returned 6241
sampleCallable531 has returned 576
sampleCallable532 has returned 7056
sampleCallable533 has returned 324
sampleCallable534 has returned 8836
sampleCallable535 has returned 676
sampleCallable536 has returned 9025
sampleCallable537 has returned 6724
sampleCallable538 has returned 3600
sampleCallable539 has returned 1849
sampleCallable540 has returned 625
sampleCallable541 has returned 1225
sampleCallable542 has returned 3025
sampleCallable543 has returned 8464
sampleCallable544 has returned 16
sampleCallable545 has returned 3969
sampleCallable546 has returned 49
sampleCallable547 has returned 2704
sampleCallable548 has returned 5476
sampleCallable549 has returned 1156
sampleCallable550 has returned 4356
sampleCallable551 has returned 7744
sampleCallable552 has returned 8281
sampleCallable553 has returned 784
sampleCallable554 has returned 2704
sampleCallable555 has returned 9604
sampleCallable556 has returned 289
sampleCallable557 has returned 900
sampleCallable558 has returned 4356
sampleCallable559 has returned 1369
sampleCallable560 has returned 8464
sampleCallable561 has returned 4489
sampleCallable562 has returned 4761
sampleCallable563 has returned 2401
sampleCallable564 has returned 3721
sampleCallable565 has returned 6400
sampleCallable566 has returned 729
sampleCallable567 has returned 2025
sampleCallable568 has returned 4356
sampleCallable569 has returned 2809
sampleCallable570 has returned 1849
sampleCallable571 has returned 5776
sampleCallable572 has returned 144
sampleCallable573 has returned 9
sampleCallable574 has returned 3136
sampleCallable575 has returned 1296
sampleCallable576 has returned 9409
sampleCallable577 has returned 289
sampleCallable578 has returned 400
sampleCallable579 has returned 3481
sampleCallable580 has returned 961
sampleCallable581 has returned 5929
sampleCallable582 has returned 4225
sampleCallable583 has returned 1849
sampleCallable584 has returned 2916
sampleCallable585 has returned 5184
sampleCallable586 has returned 169
sampleCallable587 has returned 4
sampleCallable588 has returned 1156
sampleCallable589 has returned 8836
sampleCallable590 has returned 1024
sampleCallable591 has returned 1681
sampleCallable592 has returned 1296
sampleCallable593 has returned 4096
sampleCallable594 has returned 7056
sampleCallable595 has returned 1296
sampleCallable596 has returned 10000
sampleCallable597 has returned 5776
sampleCallable598 has returned 8281
sampleCallable599 has returned 3721
sampleCallable600 has returned 576
sampleCallable601 has returned 324
sampleCallable602 has returned 256
sampleCallable603 has returned 7744
sampleCallable604 has returned 9025
sampleCallable605 has returned 3721
sampleCallable606 has returned 100
sampleCallable607 has returned 4761
sampleCallable608 has returned 4
sampleCallable609 has returned 3025
sampleCallable610 has returned 2209
sampleCallable611 has returned 6724
sampleCallable612 has returned 64

END OF EXECUTION. Thank you and try again!
 */
