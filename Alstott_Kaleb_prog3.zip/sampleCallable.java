import java.util.Random;
import java.util.concurrent.Callable;

public class sampleCallable implements Callable<Integer> {
    private int id;

    public sampleCallable(int id) {
        this.id = id;
    }

    @Override
    public Integer call() throws Exception {
        Random rand = new Random();
        // random sleep time between 150 and 300 milliseconds
        int sleepTime = rand.nextInt(151) + 150;
        // random integer between 1 and 100
        int randomInt = rand.nextInt(100) + 1;
        // print thread name and random integer
        System.out.println("Thread-" + id + " calculating square of " + randomInt);
        // sleep for the random generated sleep time
        Thread.sleep(sleepTime);
        // return the square of the random integer
        return randomInt * randomInt;
    }
}
