import java.util.Random;

public class sampleThread implements Runnable {
    private int id;

    public sampleThread(int id) {
        this.id = id;
    }

    @Override
    public void run() {
        Random rand = new Random();
        int sleepTime = rand.nextInt(500);
        try {
            // thread sleep for a random amount of time
            System.out.println("Thread" + id + " sleeping for " + sleepTime + " milliseconds.");
            Thread.sleep(sleepTime);
            // thread awake message
            System.out.println("Thread" + id + " is awake.");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
